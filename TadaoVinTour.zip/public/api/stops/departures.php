<?php
require __DIR__ . '/../../carte/api/stops/departures.php';
