<?php
// Wrapper: keep the real implementation in /carte/api (so nothing is duplicated)
require __DIR__ . '/../carte/api/bus.php';
