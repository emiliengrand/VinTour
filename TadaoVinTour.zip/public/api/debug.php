<?php
require __DIR__ . '/../carte/api/debug.php';
