import React, { useState } from "react";

// Import screens
import Onboarding1 from "./components/screens/Onboarding1";
import HomeScreen from "./components/screens/HomeScreen";
import MapScreen from "./components/screens/MapScreen";
import StopDetails from "./components/screens/StopDetails";
import WeekSchedule from "./components/screens/WeekSchedule";
import AlertSettings from "./components/screens/AlertSettings";
import AlertConfirm from "./components/screens/AlertConfirm";
import VoteHome from "./components/screens/VoteHome";
import VoteChoose from "./components/screens/VoteChoose";
import VoteConfirm from "./components/screens/VoteConfirm";
import VoteResults from "./components/screens/VoteResults";
import Profile from "./components/screens/Profile";
import FAQ from "./components/screens/FAQ";

import BottomNav from "./components/BottomNav";
import DesktopNav from "./components/DesktopNav";

export default function App() {
  const [currentScreen, setCurrentScreen] = useState("onboarding1");
  const [showOnboarding, setShowOnboarding] = useState(true);

  const navigate = (screen: string) => setCurrentScreen(screen);

  const finishOnboarding = () => {
    setShowOnboarding(false);
    setCurrentScreen("home");
  };

  const renderScreen = () => {
    switch (currentScreen) {
      case "onboarding1":
        return <Onboarding1 onNext={finishOnboarding} />;

      // Home
      case "home":
        return <HomeScreen navigate={navigate} />;

      // Map
      case "map":
        return <MapScreen navigate={navigate} />;
      case "stop-details":
        return <StopDetails navigate={navigate} />;
      case "week-schedule":
        return <WeekSchedule navigate={navigate} />;
      case "alert-settings":
        return <AlertSettings navigate={navigate} />;
      case "alert-confirm":
        return <AlertConfirm navigate={navigate} />;

      // Vote
      case "vote":
        return <VoteHome navigate={navigate} />;
      case "vote-choose":
        return <VoteChoose navigate={navigate} />;
      case "vote-confirm":
        return <VoteConfirm navigate={navigate} />;
      case "vote-results":
        return <VoteResults navigate={navigate} />;

      // Profile
      case "profile":
        return <Profile navigate={navigate} />;
      case "faq":
        return <FAQ navigate={navigate} />;

      default:
        return <HomeScreen navigate={navigate} />;
    }
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Desktop Top Nav */}
      {!showOnboarding && (
        <div className="hidden lg:block">
          <DesktopNav currentScreen={currentScreen} navigate={navigate} />
        </div>
      )}

      {/* Content (scroll normal) */}
      <div className={!showOnboarding ? "pb-20 lg:pb-0" : ""}>
        {renderScreen()}
      </div>

      {/* Bottom Nav (mobile) FIXED */}
      {!showOnboarding && (
        <div className="lg:hidden fixed bottom-0 left-0 right-0 z-50">
          <BottomNav currentScreen={currentScreen} navigate={navigate} />
        </div>
      )}
    </div>
  );
}